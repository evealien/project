package controller;
// Import packages
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Logo extends JWindow {
    public Logo(String filename, Frame flightCentre, int waitTime)
    {
        super(flightCentre);
        JLabel label = new JLabel(new ImageIcon(filename));
        getContentPane().add(label, BorderLayout.CENTER);
        pack();
        Dimension screenSize =
          Toolkit.getDefaultToolkit().getScreenSize();
        Dimension labelSize = label.getPreferredSize();
        setLocation(screenSize.width/3 - (labelSize.width/3),
                    screenSize.height/3 - (labelSize.height/3));
        addMouseListener(new MouseAdapter()
            {
                public void mousePressed(MouseEvent e)
                {
                    setVisible(false);
                    dispose();
                }
            });
        setVisible(true);
    }
}


