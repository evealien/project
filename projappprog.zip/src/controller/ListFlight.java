package controller;

import java.sql.*;
import java.awt.*;
import java.awt.event.*;


import javax.swing.*;

import model.Customer;
import view.MainUI;

public class ListFlight extends Flight{

	Customer customer1;
	public JFrame mainFrame;
	
	public ListFlight(Customer customer1) {
		this.customer1 = customer1;
		initialize();
	}
	
	private void initialize() {
		
		JPanel controlPanel = new JPanel();
		
		JButton book = new JButton("Book Now");
		controlPanel.add(book);
		book.setPreferredSize(new Dimension(200, 80));
		
		JTextField flightNumInput = new JTextField("Please Enter Flight Number");
		flightNumInput.setColumns(10);
		flightNumInput.setBounds(227, 251, 286, 42);
		controlPanel.add(flightNumInput);
		
		JButton controlMenu = new JButton("Main Menu");
		controlPanel.add(controlMenu);
		controlMenu.setPreferredSize(new Dimension(200, 80));
		controlMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				mainFrame.setVisible(false);
				new MainUI(customer1);
			
			}
		});
		
		book.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				try{
					customer1.bookFlight(Integer.parseInt(flightNumInput.getText()));;
				}
				catch (Exception ex) {
					
					ex.printStackTrace();
					
				}
				
			}
		});
		
		
		JPanel controlPanel2 = new JPanel();
		JLabel listFlights = new JLabel();
		controlPanel2.add(listFlights);
		Connection databaseConnection;
		String labelText = "<html>";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded");
			
			databaseConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb",
					"root", "root");
			
			System.out.println("Connection complete");
			
		
		Statement statement;
		
		statement = databaseConnection.createStatement();
		
		String stringList = "select * from flight";
		
		ResultSet rs = statement.executeQuery(stringList);
		
		while(rs.next()) {
			
			
			labelText = labelText + rs.getString(1) + " " + rs.getString(3) + " " + rs.getString(4) + " " + rs.getString(5)
					+ " " + rs.getString(6) + "<br>";
			}
		
		
		} catch (Exception e) {
			
			
			
		}
		
		listFlights.setText(labelText);
		System.out.println(labelText);
		
		JPanel combination = new JPanel();
		combination.add(controlPanel, BorderLayout.NORTH);
		combination.add(controlPanel2, BorderLayout.SOUTH);
		
		
		mainFrame = new JFrame();
		mainFrame.setSize(1000, 800);
		mainFrame.add(combination);
		mainFrame.setVisible(true);
		mainFrame.setResizable(false);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.getContentPane().setLayout(null);
		
	}
	
}
	
		





