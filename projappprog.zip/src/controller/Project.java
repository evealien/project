package controller;

// Import Packages
import javax.swing.*;

import view.Login;
import view.MainUI;
import java.sql.SQLException;
import java.awt.EventQueue;


public class Project {
	
	public static void main(String[] args) {
		
		Logo imgae = new Logo("src/image/flight.jpg", new JFrame(), 700);
		imgae.setVisible(true);
		
		Login userlogin;
		
		try {
			userlogin = new Login();
			userlogin.frame.setVisible(true);
		
		} catch (Exception e) {
			e.printStackTrace();
		}	 
		
	} 
	
}



