package controller;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;


import javax.swing.*;

import model.Customer;
import view.MainUI;

public class ShowFlight extends Flight{
	
	Customer customer1;
	public JFrame display;
	private JLabel list;
	private JButton btnOK;
	JPanel panel1;
	GridLayout gridLayout1;
	FlowLayout flowLayout1;
	
	public ShowFlight(Customer customer1) {
		
		this.customer1 = customer1;
		initialize();
		
	}
	
	private void initialize() {
	
		display = new JFrame();
		list = new JLabel();
		try{
			list.setText(customer1.getFlight());
		} catch(SQLException | ClassNotFoundException ex) {
			
			list.setText("There is no flights available");
			
		}
		
		btnOK = new JButton("OK");
		
		panel1 = new JPanel();
		gridLayout1 = new GridLayout();
		flowLayout1 = new FlowLayout();
		
		panel1.setLayout(gridLayout1);
		panel1.add(list);
		panel1.add(btnOK);
		btnOK.setPreferredSize(new Dimension(200, 80));
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				MainUI window;
				
				try {

					window = new MainUI(customer1);
					window.mainUI.setVisible(true);
					display.setVisible(false);
				
				} catch (Exception ex) {
					ex.printStackTrace();
					
				}	
			
			}
		});
		
		display.setLayout(flowLayout1);
		display.add(panel1);
		display.setSize(1000, 800);
		display.setResizable(false);
		display.setLocationRelativeTo(null);
		display.setVisible(true);
		display.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	}

}
