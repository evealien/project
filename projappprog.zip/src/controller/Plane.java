package controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;


public class Plane {
	
	public static String getPlaneNum(int idPlane) throws SQLException, ClassNotFoundException {
			
		Connection databaseConnection = initializeDB();
		try{
			
		Statement statement = databaseConnection.createStatement();
		
		String queryString = "select planeNum " 
				+ " from plane "
				+ " where idPlane = '" + idPlane + "'";
		
		ResultSet rs = statement.executeQuery(queryString);
		
		if (!rs.next()) {
			
		} else {
			
			return rs.getString(1);
			
		}
		
		} catch(Exception ex){
			
			ex.printStackTrace();
			
		} finally {
			
			databaseConnection.close();
			
		}
		
		return null;
		
	}
	
	public static String getAirlineName(int idPlane) throws SQLException, ClassNotFoundException {
		
		Connection databaseConnection = initializeDB();
		try{
			
		Statement statement = databaseConnection.createStatement();
		
		String queryString = "select airlineName " 
				+ " from plane "
				+ " where idPlane = '" + idPlane + "'";
		
		ResultSet rs = statement.executeQuery(queryString);
		
		if (!rs.next()) {
			
		} else {
			
			return rs.getString(1);
			
			
		}
		
		} catch(Exception ex){
			
			ex.printStackTrace();
			
		} finally {
			
			databaseConnection.close();
			
		}
		
		return null;
		
	}
	
	public static int getCapacity(int idPlane) throws SQLException, ClassNotFoundException {
		
		Connection databaseConnection = initializeDB();
		try{
			
		Statement statement = databaseConnection.createStatement();
		
		String queryString = "select capacity " 
				+ " from plane "
				+ " where idPlane = '" + idPlane + "'";
		
		ResultSet rs = statement.executeQuery(queryString);
		
		if (!rs.next()) {
			
			
		} else {
			
			return rs.getInt(1);
			
			
		}
		
		} catch(Exception ex){
			
			ex.printStackTrace();
			
		} finally {
			
			databaseConnection.close();
			
		}
		
		return 0;
		
	}
	
	public static Connection initializeDB() throws SQLException, ClassNotFoundException{
		
		try {
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver loaded");
		
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb",
				"root", "root");
		
		System.out.println("Connection complete");
		return connection;
		} catch(Exception ex){
			
			ex.printStackTrace();
			
		}
		return null;
		
	}

}
