package view;

import javax.swing.*;
import java.awt.*;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.Customer;

/**
 * Forgot Password Class
 *
 */
public class ForgotPassword extends Customer{
	/*******************************************************************/
	/*******************************************************************/
	/***********************Instance Variables**************************/ 
	/*******************************************************************/
	/*******************************************************************/
	public JFrame frame1;
	private JButton btnOK;
	private JButton btnCancel;
	private JPanel panel1;
	private GridLayout gridLayout1;
	private FlowLayout flowLayout1;
	private JLabel labelDetails;
	private JTextField userInput;

	
	/*******************************************************************/
	/*******************************************************************/
	/************************** Constructor ***************************/ 
	/*******************************************************************/
	/*******************************************************************/
	public ForgotPassword() {
		
		initialize();
		
	}
	
	public void initialize() {
		
		frame1 = new JFrame();
		btnOK = new JButton("OK");
		btnCancel = new JButton("Cancel");
		labelDetails = new JLabel("Please Enter username: ");
		userInput = new JTextField();
		panel1 = new JPanel();
		gridLayout1 = new GridLayout(1,1);
		flowLayout1 = new FlowLayout();
		
		panel1.setLayout(gridLayout1);
		panel1.add(labelDetails);
		panel1.add(userInput);
		/**
		 * Input validation and checking function
		 * 
		 */
		panel1.add(btnOK);
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Customer c1 = new Customer(userInput.getText());
				try{
					
					c1.getInformation();
					if (c1.getSSN() != 0) {
					
						System.out.println(c1.getUsername());
						System.out.println(userInput.getText());
						labelDetails.setText(c1.getSecurityQuestion());
							
							
						btnOK.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent e) {
							
								if (userInput.getText().equals(c1.getSecurityAnswer())) {
									
									JOptionPane.showMessageDialog(null, c1.getPassword());
									
								} else {
									
									JOptionPane.showMessageDialog(null, "Incorrect Answer");
									
									
								}
							
							}
							
						});  
					
					} else {
						
						JOptionPane.showMessageDialog(null, "Username does not exist");
						
					}
					
				} catch (Exception ex) {

					ex.printStackTrace();
					
				}
				
			}
		});
		
		panel1.add(btnCancel);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login window;
				
				try {
				/**
				 * Running the selected login page
				 */
					window = new Login();
					window.frame.setVisible(true);
					frame1.setVisible(false);
				
				} catch (Exception ex) {
					ex.printStackTrace();
					
				}	
				
			}
		});
		
		frame1.setLayout(flowLayout1);
		frame1.add(panel1);
		frame1.setSize(1000,800);
		frame1.setVisible(true);
		
		
		
		
	}
	
	
	

}
