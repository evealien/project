package view;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import controller.ListFlight;
import controller.ShowFlight;
import model.Customer;

public class MainUI extends JFrame{
	/*******************************************************************/
	/*******************************************************************/
	/***********************Instance Variables**************************/ 
	/*******************************************************************/
	/*******************************************************************/
	public JFrame mainUI;
	private JButton listFlights = new JButton("List Flight");
	private JButton myFlights = new JButton("My Flights");
	private JButton logout = new JButton("Logout");
	private JButton addUpdateFlight = new JButton("Add/Update Flight");
	Customer customer1;
	/*******************************************************************/
	/*******************************************************************/
	/************************** Constructor ***************************/ 
	/*******************************************************************/
	/*******************************************************************/
	public MainUI(Customer customer1) {
		this.customer1 = customer1;
		initialize();
	}
	
	private void initialize() {
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new GridLayout(1,2));
		
		mainPanel.add(listFlights);
		listFlights.setPreferredSize(new Dimension(200, 80));
		listFlights.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					ListFlight flight = new ListFlight(customer1);
					mainUI.setVisible(false);
					
				} catch (Exception e1) {
					
					JOptionPane.showMessageDialog(null, "Error");
					e1.printStackTrace();
				}
			}
		});
		
		mainPanel.add(myFlights);
		myFlights.setPreferredSize(new Dimension(200, 80));
		myFlights.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				ShowFlight window;
				
				try {
				/**
				 * To operate the show flight function
				 */
					window = new ShowFlight(customer1);
					mainUI.setVisible(false);
				
				} catch (Exception ex) {
					ex.printStackTrace();
					
				}	
				
			}
		});
		
		mainPanel.add(logout);
		logout.setPreferredSize(new Dimension(200, 80));
		logout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Login window;
				
				try {
				/**
				 * Operate login page
				 */
					window = new Login();
					window.frame.setVisible(true);
					mainUI.setVisible(false);
				
				} catch (Exception ex) {
					ex.printStackTrace();
					
				}	
				
			}
		});
		
		if(customer1.getAdmin() == 1) {
			mainPanel.add(addUpdateFlight);
			addUpdateFlight.setPreferredSize(new Dimension(200, 80));
			addUpdateFlight.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
	
					FlightForm window;
					
					try {
					/**
					 * Operate Flight form page
					 * 
					 */
						window = new FlightForm(customer1);
						window.mainForm.setVisible(true);
						mainUI.setVisible(false);
					
					} catch (Exception ex) {
						ex.printStackTrace();
						
					}	
					
				}
			});
		}
		JPanel mainPanel2 = new JPanel();
		JPanel mainPanelUI = new JPanel();
		mainPanelUI.add(mainPanel, BorderLayout.SOUTH);
		mainPanelUI.add(mainPanel2, BorderLayout.CENTER);
		
		mainUI = new JFrame();
		mainUI.setSize(1000, 800);
		mainUI.setResizable(false);
		mainUI.setLocationRelativeTo(null);
		mainUI.add(mainPanelUI);
		mainUI.setVisible(true);
		mainUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
}
