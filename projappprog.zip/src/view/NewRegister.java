package view; 

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import model.Customer;
import model.User;
 /**
  * Registration function
  *
  */
public class NewRegister {
		
	public JFrame newReg;
	private JLabel firstName;
	private JLabel lastName;
	private JLabel address;
	private JLabel zip;
	private JLabel state;
	private JLabel email;
	private JLabel ssn; 
	private JLabel securityQuestion;
	private JLabel securityAnswer;
	private JLabel username; 
	private JLabel password;
	private JLabel admin;
	
	private JTextField enterFName;
	private JTextField enterLName;
	private JTextField enterAddress;
	private JTextField enterZip;
	private JTextField enterState;
	private JTextField enterEmail;
	private JTextField enterSSN;
	private JTextField enterQuestion;
	private JTextField enterAnswer;
	private JTextField enterUsername; 
	private JTextField enterPassword;
	private JButton setRegister;
	private JButton cancelRegister;
	JPanel panel1;
	JPanel panel2;
	GridLayout gridLayout1;
	GridLayout gridLayout2;
	FlowLayout flowLayout1;
	
	public NewRegister() {
		initialize();
	}
	
	private void initialize() {
		
		newReg = new JFrame();
		newReg.setSize(1000, 800);
		newReg.setResizable(false);
		newReg.setLocationRelativeTo(null);
		newReg.setVisible(true);
		newReg.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		firstName = new JLabel("First Name: ");
		lastName = new JLabel("Last Name: ");
		address = new JLabel("Address");
		zip = new JLabel("Zip");
		state = new JLabel("State"); 
		email = new JLabel("Email");
		ssn = new JLabel("SSN"); 
		securityQuestion = new JLabel ("Security Question");
		securityAnswer = new JLabel("Security Answer"); 
		username = new JLabel("Username"); 
		password = new JLabel("Password"); 
		admin = new JLabel("Admin");
		
		enterFName = new JTextField();
		enterLName = new JTextField();
		enterAddress = new JTextField();
		enterZip = new JTextField();
		enterState = new JTextField();
		enterEmail = new JTextField();
		enterSSN = new JTextField();
		enterQuestion = new JTextField();
		enterAnswer = new JTextField();
		enterUsername = new JTextField();
		enterPassword = new JTextField();
		
		setRegister = new JButton("Register");
		cancelRegister = new JButton("Cancel");
		
		panel1 = new JPanel();
		panel2 = new JPanel();
		
		gridLayout1 = new GridLayout(22,1);
		gridLayout2 = new GridLayout(1,1);
		
		flowLayout1 = new FlowLayout();
		
		panel1.setLayout(gridLayout1);
		panel1.add(firstName);
		panel1.add(enterFName);
		panel1.add(lastName);
		panel1.add(enterLName);
		panel1.add(address);
		panel1.add(enterAddress);
		panel1.add(zip);
		panel1.add(enterZip);
		panel1.add(state);
		panel1.add(enterState);
		panel1.add(email);
		panel1.add(enterEmail);
		panel1.add(ssn);
		panel1.add(enterSSN);
		panel1.add(securityQuestion);
		panel1.add(enterQuestion);
		panel1.add(securityAnswer);
		panel1.add(enterAnswer);
		panel1.add(username);
		panel1.add(enterUsername);
		panel1.add(password);
		panel1.add(enterPassword);
		
		panel2.setLayout(gridLayout2);
		panel2.add(setRegister);
		setRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Customer customer1 = new Customer(enterFName.getText(), enterLName.getText(), enterAddress.getText(), enterState.getText(), Integer.parseInt(enterZip.getText()), 
						enterEmail.getText(), Integer.parseInt(enterSSN.getText()), enterQuestion.getText(), enterAnswer.getText(), enterUsername.getText(), enterPassword.getText(), 0);
				
				try {
					
					customer1.add();
					JOptionPane.showMessageDialog(null, "Registered Successfully");
					
				} catch(Exception ex) {
					
					JOptionPane.showMessageDialog(null, "Error");
					ex.printStackTrace();
					
				}
				
			}
		});
		newReg.getContentPane().add(setRegister);
		
		panel2.add(cancelRegister);
		cancelRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login window;
				try {
					// Running login page
					window = new Login();
					window.frame.setVisible(true);
					newReg.setVisible(false);
				
				} catch (Exception ex) {
					ex.printStackTrace();
					
				}	
				
			}
		});
		newReg.getContentPane().add(cancelRegister);
		newReg.setLayout(gridLayout2);
		newReg.add(panel1, BorderLayout.NORTH);
		newReg.add(panel2, BorderLayout.SOUTH);
		newReg.setSize(1000,800);
		newReg.setVisible(true);
	}

}


