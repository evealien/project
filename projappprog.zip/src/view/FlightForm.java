package view;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import controller.Flight;
import model.Customer;
/**
 * 
 *
 */
public class FlightForm extends Flight {
	/*******************************************************************/
	/*******************************************************************/
	/***********************Instance Variables**************************/ 
	/*******************************************************************/
	/*******************************************************************/
	
	public JFrame mainForm;
	private JLabel flightID, planeID, flightTo, flightFrom, depart, arrive;
	private JTextField enterFID, enterPID, enterFTo, enterFFrom, enterDepart, enterArrive;
	private JButton addFlight, cancelAdd;
	
	Customer customer1;
	JPanel panel1, panel2;
	GridLayout gridLayout1, gridLayout2;
	FlowLayout flowLayout1;
	
	/*******************************************************************/
	/*******************************************************************/
	/************************** Constructor ***************************/ 
	/*******************************************************************/
	/*******************************************************************/
	public FlightForm(Customer customer1) {
		
		this.customer1 = customer1;
		initialize();
		
	}
	
	private void initialize() {
		
		mainForm = new JFrame();
		mainForm.setSize(1200, 800);
		mainForm.setResizable(false);
		mainForm.setLocationRelativeTo(null);
		mainForm.setVisible(true);
		mainForm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		flightID = new JLabel("Flight ID: ");
		planeID = new JLabel("AirPlane ID: ");
		flightTo = new JLabel("To: ");
		flightFrom = new JLabel("From: ");
		depart = new JLabel("Departure Time: ");
		arrive = new JLabel("Arrival Time: ");
		
		enterFID = new JTextField("FID");
		enterPID = new JTextField("PID");
		enterFTo = new JTextField("To(City, State)");
		enterFFrom = new JTextField("From(City, State)");
		enterDepart = new JTextField("YYYY-MM-DD HH-MM-SS");
		enterArrive = new JTextField("YYYY-MM-DD HH-MM-SS");
		
		addFlight = new JButton("Add");
		cancelAdd = new JButton("Cancel");
		
		panel1 = new JPanel();
		panel2 = new JPanel();
		
		gridLayout1 = new GridLayout(22,1);
		gridLayout2 = new GridLayout(1,1);
		
		flowLayout1 = new FlowLayout();
		
		panel1.setLayout(gridLayout1);
		panel1.add(flightID);
		panel1.add(enterFID);
		panel1.add(planeID);
		panel1.add(enterPID);
		panel1.add(flightTo);
		panel1.add(enterFTo);
		panel1.add(flightFrom);
		panel1.add(enterFFrom);
		panel1.add(depart);
		panel1.add(enterDepart);
		panel1.add(arrive);
		panel1.add(enterArrive);
		
		panel2.setLayout(gridLayout2);
		panel2.add(addFlight);
		addFlight.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				
				Date parsedDate;
				Date parsedDate2;
				
				Timestamp timestamp = null;
				Timestamp timestampanel2 = null;
				try {
					parsedDate = dateFormat.parse(enterDepart.getText());
					parsedDate2 = dateFormat2.parse(enterArrive.getText());
					
					timestamp = new Timestamp(parsedDate.getTime());
					timestampanel2 = new Timestamp(parsedDate2.getTime());
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				Flight flowLayout1 =  new Flight(Integer.parseInt(enterFID.getText()), Integer.parseInt(enterPID.getText()), enterFTo.getText(), 
						enterFFrom.getText(), timestamp, timestampanel2);
				
				try {
					
					flowLayout1.add();
					JOptionPane.showMessageDialog(null, "is Successfully added");
					
				} catch(SQLException ex){
					
					JOptionPane.showMessageDialog(null, "Sorry, the Flight ID already exists!");
					ex.printStackTrace();
					
				} catch(Exception ex) {
					
					ex.printStackTrace();
					
				}
				
			}
		});
		
		panel2.add(cancelAdd);
		cancelAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				MainUI window;
				
				try {

					window = new MainUI(customer1);
					window.mainUI.setVisible(true);
					mainForm.setVisible(false);
				
				} catch (Exception ex) {
					ex.printStackTrace();
					
				}	
				
			}
		});
		
		mainForm.setLayout(gridLayout2);
		mainForm.add(panel1);
		mainForm.add(panel2);
		mainForm.setSize(1000, 800);
		mainForm.setVisible(true);
		
		
		
		
	}
	
}
