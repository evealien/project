package view;

import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import model.Customer;

public class Login extends JFrame {
	/*******************************************************************/
	/*******************************************************************/
	/***********************Instance Variables**************************/ 
	/*******************************************************************/
	/*******************************************************************/
	public JFrame frame;
	protected JTextField userNameInput;
	private JTextField passwordInput;
	/*******************************************************************/
	/*******************************************************************/
	/************************** Constructor ***************************/ 
	/*******************************************************************/
	/*******************************************************************/
	public Login() {
		initialize();
	}

	/**
	 * Initialization of Frame
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 970, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel reservationSystemInput = new JLabel("Fligt Reservation System - Welcome");
		reservationSystemInput.setBounds(327, 40, 556, 71);
		reservationSystemInput.setFont(new Font("Tahoma", Font.BOLD, 28));
		frame.getContentPane().add(reservationSystemInput);
		
		JLabel usernameLabel = new JLabel("Username:");
		usernameLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		usernameLabel.setBounds(61, 166, 124, 42);
		frame.getContentPane().add(usernameLabel);
		
		JLabel passwordLabel = new JLabel("Password:");
		passwordLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		passwordLabel.setBounds(61, 251, 124, 42);
		frame.getContentPane().add(passwordLabel);
		
		userNameInput = new JTextField();
		userNameInput.setBounds(227, 166, 286, 42);
		frame.getContentPane().add(userNameInput);
		userNameInput.setColumns(10);
		
		passwordInput = new JTextField();
		passwordInput.setColumns(10);
		passwordInput.setBounds(227, 251, 286, 42);
		frame.getContentPane().add(passwordInput);
		
		JButton forgotPasswordBTN = new JButton("Forgot Password?");
		forgotPasswordBTN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					frame.setVisible(false);
					frame = null;
					ForgotPassword lookupPass = new ForgotPassword();
					
				} catch (Exception e1) {
					
					JOptionPane.showMessageDialog(null, "Error");
					
				}
			}
		});
		forgotPasswordBTN.setBounds(582, 361, 124, 33);
		forgotPasswordBTN.setSize(200,50);
		frame.getContentPane().add(forgotPasswordBTN);
		
		JButton loginBTN = new JButton("Login");
		loginBTN.setFont(new Font("Tahoma", Font.BOLD, 20));
		loginBTN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					Customer customer1 = new Customer(userNameInput.getText());
					customer1.getInformation();
					
					if(customer1.getPassword().equals(passwordInput.getText())) {
						frame.setVisible(false);
						frame = null;
						new MainUI(customer1);
					} else {
						
						JOptionPane.showMessageDialog(null, "Invalid username or password", "Error", JOptionPane.INFORMATION_MESSAGE);
						
					}
				
				}
				catch (Exception e1) {
					JOptionPane.showMessageDialog(null, "Invalid username or password");
				}
			}
		});
		loginBTN.setBounds(227, 345, 286, 56);
		loginBTN.setSize(200,50);
		frame.getContentPane().add(loginBTN);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					frame.setVisible(false);
					frame = null;
					new NewRegister();
					
				} catch (Exception e1) {
					
					JOptionPane.showMessageDialog(null, "Error");
					
				}
			}
		});
		btnRegister.setBounds(582, 306, 124, 33);
		btnRegister.setSize(200,50);
		frame.getContentPane().add(btnRegister);

	}
	
}


