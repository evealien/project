package database;

import java.sql.*;

// Interface Class for database connection 

public interface databaseVerification {
	
	public abstract Connection initializeDB() 
			throws SQLException, ClassNotFoundException;
	
	public abstract void add()
			throws SQLException, ClassNotFoundException;
	
	public abstract void delete()
			throws SQLException, ClassNotFoundException;
	
	public abstract void update()
			throws SQLException, ClassNotFoundException;
	
}
